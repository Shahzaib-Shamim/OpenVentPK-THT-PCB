top pour added
botton traces adjusted
some jumpers silkscreen added
ver no updated
switch silkscreen added
pour paramters changed
ftdi note on silkscreen added