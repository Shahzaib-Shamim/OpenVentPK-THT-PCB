EESchema Schematic File Version 4
EELAYER 30 0
EELAYER END
$Descr A4 11693 8268
encoding utf-8
Sheet 1 3
Title "OpenVentPK PCB Project V2I1"
Date "2021-11-18"
Rev "Rev. 2.0"
Comp "OpenVentPK"
Comment1 ""
Comment2 ""
Comment3 "SHAHZAIB SHAMIM"
Comment4 "Designed by:"
$EndDescr
$Sheet
S 6200 1550 1700 950 
U 618968DF
F0 "ARDUINO MEGA" 50
F1 "ARDUINO MEGA.sch" 50
$EndSheet
$Sheet
S 4400 1550 1700 950 
U 618968A3
F0 "ARDUINO UNO" 50
F1 "ARDUINO UNO.sch" 50
$EndSheet
Text Notes 4450 850  0    200  ~ 40
TOP LEVEL SCHEMATIC
$EndSCHEMATC
