EESchema Schematic File Version 4
EELAYER 30 0
EELAYER END
$Descr A4 11693 8268
encoding utf-8
Sheet 3 3
Title "OpenVentPK PCB Project V2I1"
Date "2021-11-18"
Rev "Rev. 2.0"
Comp "OpenVentPK"
Comment1 ""
Comment2 ""
Comment3 "SHAHZAIB SHAMIM"
Comment4 "Designed by:"
$EndDescr
$Comp
L SchematicLibrary:GND #PWR067
U 1 1 6189B462
P 6100 4550
F 0 "#PWR067" H 6100 4300 50  0001 C CNN
F 1 "GND" H 6105 4377 50  0000 C CNN
F 2 "" H 6100 4550 50  0001 C CNN
F 3 "" H 6100 4550 50  0001 C CNN
	1    6100 4550
	1    0    0    -1  
$EndComp
Wire Wire Line
	6000 4450 6000 4500
Wire Wire Line
	6000 4500 6100 4500
Wire Wire Line
	6200 4500 6200 4450
Wire Wire Line
	6100 4450 6100 4500
Connection ~ 6100 4500
Wire Wire Line
	6100 4500 6200 4500
Wire Wire Line
	6100 4550 6100 4500
NoConn ~ 6600 3350
NoConn ~ 6600 3450
NoConn ~ 6600 3550
NoConn ~ 6600 3650
NoConn ~ 6600 3750
NoConn ~ 6600 3850
NoConn ~ 6600 4050
NoConn ~ 6600 4150
Wire Wire Line
	5600 2750 4600 2750
Wire Wire Line
	5600 2850 4600 2850
NoConn ~ 5600 3150
Wire Wire Line
	4600 3250 5600 3250
Wire Wire Line
	4600 3350 5600 3350
NoConn ~ 5600 3450
NoConn ~ 5600 3550
Wire Wire Line
	5600 3650 5500 3650
Wire Wire Line
	5500 3750 5600 3750
NoConn ~ 6600 2950
$Comp
L Connector:Conn_01x06_Male J11
U 1 1 61FBFF7C
P 10200 2400
F 0 "J11" H 10200 2700 50  0000 C CNN
F 1 "Conn_01x06_Male" H 10200 2000 50  0001 C CNN
F 2 "Connector_JST:JST_XH_B6B-XH-A_1x06_P2.50mm_Vertical" H 10200 2400 50  0001 C CNN
F 3 "~" H 10200 2400 50  0001 C CNN
	1    10200 2400
	-1   0    0    -1  
$EndComp
Wire Wire Line
	10000 2300 9900 2300
Wire Wire Line
	9900 2300 9900 2500
Wire Wire Line
	10000 2500 9900 2500
Connection ~ 9900 2500
Wire Wire Line
	9900 2500 9900 2700
Wire Wire Line
	10000 2700 9900 2700
Connection ~ 9900 2700
Wire Wire Line
	9900 2700 9900 2900
$Comp
L SchematicLibrary:GND #PWR073
U 1 1 61FC2B25
P 9900 2900
F 0 "#PWR073" H 9900 2650 50  0001 C CNN
F 1 "GND" H 9905 2727 50  0000 C CNN
F 2 "" H 9900 2900 50  0001 C CNN
F 3 "" H 9900 2900 50  0001 C CNN
	1    9900 2900
	1    0    0    -1  
$EndComp
Wire Wire Line
	10000 2200 9450 2200
Wire Wire Line
	10000 2400 9450 2400
Wire Wire Line
	10000 2600 9450 2600
Text Label 9450 2200 0    50   ~ 0
STEP
Text Label 9450 2400 0    50   ~ 0
DIR
Text Label 9450 2600 0    50   ~ 0
EN1
$Comp
L Connector:Conn_01x06_Male J12
U 1 1 61FC688F
P 10200 4200
F 0 "J12" H 10200 4500 50  0000 C CNN
F 1 "Conn_01x06_Male" H 10200 3800 50  0001 C CNN
F 2 "Connector_JST:JST_XH_B6B-XH-A_1x06_P2.50mm_Vertical" H 10200 4200 50  0001 C CNN
F 3 "~" H 10200 4200 50  0001 C CNN
	1    10200 4200
	-1   0    0    -1  
$EndComp
Wire Wire Line
	10000 4100 9900 4100
Wire Wire Line
	9900 4100 9900 4300
Wire Wire Line
	10000 4300 9900 4300
Connection ~ 9900 4300
Wire Wire Line
	9900 4300 9900 4500
Wire Wire Line
	10000 4500 9900 4500
Connection ~ 9900 4500
Wire Wire Line
	9900 4500 9900 4700
$Comp
L SchematicLibrary:GND #PWR074
U 1 1 61FC689D
P 9900 4700
F 0 "#PWR074" H 9900 4450 50  0001 C CNN
F 1 "GND" H 9905 4527 50  0000 C CNN
F 2 "" H 9900 4700 50  0001 C CNN
F 3 "" H 9900 4700 50  0001 C CNN
	1    9900 4700
	1    0    0    -1  
$EndComp
Wire Wire Line
	10000 4000 9450 4000
Wire Wire Line
	10000 4200 9450 4200
Wire Wire Line
	10000 4400 9450 4400
Text Label 9450 4000 0    50   ~ 0
STEP
Text Label 9450 4200 0    50   ~ 0
DIR
Text Label 9450 4400 0    50   ~ 0
EN2
$Comp
L Device:C C?
U 1 1 618C3676
P 6900 3350
AR Path="/618968DF/618C3676" Ref="C?"  Part="1" 
AR Path="/618968A3/618C3676" Ref="C40"  Part="1" 
F 0 "C40" H 7015 3396 50  0000 L CNN
F 1 "100nF" H 7015 3305 50  0000 L CNN
F 2 "Capacitor_THT:C_Disc_D5.0mm_W2.5mm_P2.50mm" H 6938 3200 50  0001 C CNN
F 3 "~" H 6900 3350 50  0001 C CNN
	1    6900 3350
	1    0    0    -1  
$EndComp
$Comp
L SchematicLibrary:GND #PWR?
U 1 1 618C367D
P 6900 3600
AR Path="/618968DF/618C367D" Ref="#PWR?"  Part="1" 
AR Path="/618968A3/618C367D" Ref="#PWR070"  Part="1" 
F 0 "#PWR070" H 6900 3350 50  0001 C CNN
F 1 "GND" H 6900 3450 50  0001 C CNN
F 2 "" H 6900 3600 50  0001 C CNN
F 3 "" H 6900 3600 50  0001 C CNN
	1    6900 3600
	-1   0    0    -1  
$EndComp
Wire Wire Line
	6900 3500 6900 3600
Wire Wire Line
	6600 3150 6900 3150
Wire Wire Line
	6900 3150 6900 3200
Text Label 6900 3150 2    50   ~ 0
+AREF
$Comp
L Device:R_US R?
U 1 1 618CEA62
P 7350 2550
AR Path="/618968DF/618CEA62" Ref="R?"  Part="1" 
AR Path="/618968A3/618CEA62" Ref="R44"  Part="1" 
F 0 "R44" H 7282 2504 50  0000 R CNN
F 1 "100k" H 7282 2595 50  0000 R CNN
F 2 "Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal" V 7390 2540 50  0001 C CNN
F 3 "~" H 7350 2550 50  0001 C CNN
	1    7350 2550
	-1   0    0    1   
$EndComp
$Comp
L Device:R_US R?
U 1 1 618CEA6E
P 7050 2750
AR Path="/618968DF/618CEA6E" Ref="R?"  Part="1" 
AR Path="/618968A3/618CEA6E" Ref="R43"  Part="1" 
F 0 "R43" V 6950 2750 50  0000 C CNN
F 1 "22" V 7150 2750 50  0000 C CNN
F 2 "Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal" V 7090 2740 50  0001 C CNN
F 3 "~" H 7050 2750 50  0001 C CNN
	1    7050 2750
	0    1    1    0   
$EndComp
$Comp
L Switch:SW_Push SW?
U 1 1 618CEA74
P 7350 3000
AR Path="/618968DF/618CEA74" Ref="SW?"  Part="1" 
AR Path="/618968A3/618CEA74" Ref="SW2"  Part="1" 
F 0 "SW2" V 7400 3250 50  0000 C CNN
F 1 "SW_Push" V 7250 3250 50  0001 C CNN
F 2 "Button_Switch_THT:SW_PUSH_6mm_H5mm" H 7350 3200 50  0001 C CNN
F 3 "~" H 7350 3200 50  0001 C CNN
	1    7350 3000
	0    1    -1   0   
$EndComp
$Comp
L SchematicLibrary:GND #PWR?
U 1 1 618CEA7A
P 7350 3250
AR Path="/618968DF/618CEA7A" Ref="#PWR?"  Part="1" 
AR Path="/618968A3/618CEA7A" Ref="#PWR072"  Part="1" 
F 0 "#PWR072" H 7350 3000 50  0001 C CNN
F 1 "GND" H 7350 3100 50  0001 C CNN
F 2 "" H 7350 3250 50  0001 C CNN
F 3 "" H 7350 3250 50  0001 C CNN
	1    7350 3250
	1    0    0    -1  
$EndComp
Wire Wire Line
	7350 2700 7350 2750
Wire Wire Line
	7350 2750 7200 2750
Connection ~ 7350 2750
Wire Wire Line
	7350 2750 7350 2800
Wire Wire Line
	7350 3200 7350 3250
Wire Wire Line
	7350 2750 7900 2750
Text Label 7850 2750 2    50   ~ 0
UNO_~RST
Wire Wire Line
	6900 2750 6600 2750
$Comp
L Diode:1N5819 D?
U 1 1 618D742F
P 8050 2750
AR Path="/618968DF/618D742F" Ref="D?"  Part="1" 
AR Path="/618968A3/618D742F" Ref="D7"  Part="1" 
F 0 "D7" H 8050 2850 50  0000 C CNN
F 1 "1N5819" H 8050 2650 50  0000 C CNN
F 2 "Diode_THT:D_DO-41_SOD81_P10.16mm_Horizontal" H 8050 2575 50  0001 C CNN
F 3 "http://www.vishay.com/docs/88525/1n5817.pdf" H 8050 2750 50  0001 C CNN
	1    8050 2750
	1    0    0    1   
$EndComp
Text GLabel 8250 2750 2    50   Input ~ 0
UNO_~RST_S
Wire Wire Line
	8250 2750 8200 2750
$Comp
L Jumper:Jumper_3_Bridged12 JP13
U 1 1 619757D9
P 1850 4400
F 0 "JP13" H 1850 4604 50  0000 C CNN
F 1 "Jumper_3_Bridged12" H 1850 4513 50  0001 C CNN
F 2 "Connector_PinHeader_2.54mm:PinHeader_1x03_P2.54mm_Vertical" H 1850 4400 50  0001 C CNN
F 3 "~" H 1850 4400 50  0001 C CNN
	1    1850 4400
	1    0    0    -1  
$EndComp
$Comp
L Jumper:Jumper_3_Bridged12 JP14
U 1 1 619778DD
P 1850 4900
F 0 "JP14" H 1850 5104 50  0000 C CNN
F 1 "Jumper_3_Bridged12" H 1850 5013 50  0001 C CNN
F 2 "Connector_PinHeader_2.54mm:PinHeader_1x03_P2.54mm_Vertical" H 1850 4900 50  0001 C CNN
F 3 "~" H 1850 4900 50  0001 C CNN
	1    1850 4900
	1    0    0    -1  
$EndComp
Wire Wire Line
	1850 4550 1850 4600
Wire Wire Line
	1850 4600 2300 4600
Wire Wire Line
	1850 5050 1850 5100
Wire Wire Line
	1850 5100 2300 5100
Wire Wire Line
	1600 4400 1400 4400
Wire Wire Line
	1400 4900 1600 4900
Text GLabel 1400 4900 0    50   Input ~ 0
UNO_RX2
Text GLabel 1400 4400 0    50   Output ~ 0
UNO_TX2
Text Label 4600 2750 0    50   ~ 0
RX
Text Label 4600 2850 0    50   ~ 0
TX
Text Label 2300 5100 2    50   ~ 0
RX
Text Label 2300 4600 2    50   ~ 0
TX
$Comp
L Device:R_US R?
U 1 1 6198F66F
P 5350 3650
AR Path="/618968DF/6198F66F" Ref="R?"  Part="1" 
AR Path="/618968A3/6198F66F" Ref="R41"  Part="1" 
F 0 "R41" V 5300 3500 50  0000 C CNN
F 1 "22" V 5300 3800 50  0000 C CNN
F 2 "Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal" V 5390 3640 50  0001 C CNN
F 3 "~" H 5350 3650 50  0001 C CNN
	1    5350 3650
	0    1    1    0   
$EndComp
$Comp
L Device:R_US R?
U 1 1 61993B3C
P 5350 3750
AR Path="/618968DF/61993B3C" Ref="R?"  Part="1" 
AR Path="/618968A3/61993B3C" Ref="R42"  Part="1" 
F 0 "R42" V 5300 3600 50  0000 C CNN
F 1 "22" V 5300 3900 50  0000 C CNN
F 2 "Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal" V 5390 3740 50  0001 C CNN
F 3 "~" H 5350 3750 50  0001 C CNN
	1    5350 3750
	0    1    1    0   
$EndComp
Wire Wire Line
	5200 3650 4600 3650
Wire Wire Line
	4600 3750 5200 3750
Text Label 4600 3650 0    50   ~ 0
STEP
Text Label 4600 3750 0    50   ~ 0
DIR
Text Label 4600 3050 0    50   ~ 0
EN1
$Comp
L Device:R_US R?
U 1 1 6199A5CA
P 5350 2950
AR Path="/618968DF/6199A5CA" Ref="R?"  Part="1" 
AR Path="/618968A3/6199A5CA" Ref="R39"  Part="1" 
F 0 "R39" V 5300 2800 50  0000 C CNN
F 1 "22" V 5300 3100 50  0000 C CNN
F 2 "Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal" V 5390 2940 50  0001 C CNN
F 3 "~" H 5350 2950 50  0001 C CNN
	1    5350 2950
	0    1    1    0   
$EndComp
$Comp
L Device:R_US R?
U 1 1 6199A5D0
P 5350 3050
AR Path="/618968DF/6199A5D0" Ref="R?"  Part="1" 
AR Path="/618968A3/6199A5D0" Ref="R40"  Part="1" 
F 0 "R40" V 5300 2900 50  0000 C CNN
F 1 "22" V 5300 3200 50  0000 C CNN
F 2 "Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal" V 5390 3040 50  0001 C CNN
F 3 "~" H 5350 3050 50  0001 C CNN
	1    5350 3050
	0    1    1    0   
$EndComp
Wire Wire Line
	5200 2950 4600 2950
Wire Wire Line
	4600 3050 5200 3050
Wire Wire Line
	5600 2950 5500 2950
Wire Wire Line
	5500 3050 5600 3050
Text Label 4600 2950 0    50   ~ 0
EN2
Text Label 4600 3350 0    50   ~ 0
LIMIT_SW_1
Text Label 4600 3250 0    50   ~ 0
LIMIT_SW_2
$Comp
L Connector:Conn_01x06_Male J9
U 1 1 61A646A1
P 900 1900
F 0 "J9" H 900 2200 50  0000 C CNN
F 1 "Conn_01x06_Male" H 900 1500 50  0001 C CNN
F 2 "Connector_JST:JST_XH_B6B-XH-A_1x06_P2.50mm_Vertical" H 900 1900 50  0001 C CNN
F 3 "~" H 900 1900 50  0001 C CNN
	1    900  1900
	1    0    0    -1  
$EndComp
$Comp
L Device:C C?
U 1 1 61A6BF2B
P 1750 2000
AR Path="/618968DF/61A6BF2B" Ref="C?"  Part="1" 
AR Path="/618968A3/61A6BF2B" Ref="C35"  Part="1" 
F 0 "C35" H 1865 2046 50  0000 L CNN
F 1 "100nF" H 1865 1955 50  0000 L CNN
F 2 "Capacitor_THT:C_Disc_D5.0mm_W2.5mm_P2.50mm" H 1788 1850 50  0001 C CNN
F 3 "~" H 1750 2000 50  0001 C CNN
	1    1750 2000
	1    0    0    -1  
$EndComp
$Comp
L Device:R_US R?
U 1 1 61A6BF31
P 1550 1800
AR Path="/618968DF/61A6BF31" Ref="R?"  Part="1" 
AR Path="/618968A3/61A6BF31" Ref="R33"  Part="1" 
F 0 "R33" V 1450 1800 50  0000 C CNN
F 1 "22" V 1650 1800 50  0000 C CNN
F 2 "Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal" V 1590 1790 50  0001 C CNN
F 3 "~" H 1550 1800 50  0001 C CNN
	1    1550 1800
	0    1    1    0   
$EndComp
$Comp
L SchematicLibrary:GND #PWR?
U 1 1 61A6BF43
P 1750 2250
AR Path="/618968DF/61A6BF43" Ref="#PWR?"  Part="1" 
AR Path="/618968A3/61A6BF43" Ref="#PWR061"  Part="1" 
F 0 "#PWR061" H 1750 2000 50  0001 C CNN
F 1 "GND" H 1750 2100 50  0001 C CNN
F 2 "" H 1750 2250 50  0001 C CNN
F 3 "" H 1750 2250 50  0001 C CNN
	1    1750 2250
	1    0    0    -1  
$EndComp
Wire Wire Line
	1700 1800 1750 1800
Wire Wire Line
	1750 1800 1750 1850
Wire Wire Line
	1750 1800 2300 1800
Connection ~ 1750 1800
$Comp
L Device:R_US R?
U 1 1 61A6BF5D
P 1750 1600
AR Path="/618968DF/61A6BF5D" Ref="R?"  Part="1" 
AR Path="/618968A3/61A6BF5D" Ref="R36"  Part="1" 
F 0 "R36" H 1682 1554 50  0000 R CNN
F 1 "10k" H 1682 1645 50  0000 R CNN
F 2 "Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal" V 1790 1590 50  0001 C CNN
F 3 "~" H 1750 1600 50  0001 C CNN
	1    1750 1600
	-1   0    0    1   
$EndComp
Text Label 2300 1800 2    50   ~ 0
LIMIT_SW_2
Text Label 2300 3000 2    50   ~ 0
LIMIT_SW_1
Wire Wire Line
	1750 2150 1750 2250
Wire Wire Line
	1750 1800 1750 1750
Wire Wire Line
	1750 1450 1750 1400
$Comp
L Device:C C?
U 1 1 61A7F16F
P 1750 3200
AR Path="/618968DF/61A7F16F" Ref="C?"  Part="1" 
AR Path="/618968A3/61A7F16F" Ref="C36"  Part="1" 
F 0 "C36" H 1865 3246 50  0000 L CNN
F 1 "100nF" H 1865 3155 50  0000 L CNN
F 2 "Capacitor_THT:C_Disc_D5.0mm_W2.5mm_P2.50mm" H 1788 3050 50  0001 C CNN
F 3 "~" H 1750 3200 50  0001 C CNN
	1    1750 3200
	1    0    0    -1  
$EndComp
$Comp
L Device:R_US R?
U 1 1 61A7F175
P 1550 3000
AR Path="/618968DF/61A7F175" Ref="R?"  Part="1" 
AR Path="/618968A3/61A7F175" Ref="R34"  Part="1" 
F 0 "R34" V 1450 3000 50  0000 C CNN
F 1 "22" V 1650 3000 50  0000 C CNN
F 2 "Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal" V 1590 2990 50  0001 C CNN
F 3 "~" H 1550 3000 50  0001 C CNN
	1    1550 3000
	0    1    1    0   
$EndComp
$Comp
L SchematicLibrary:GND #PWR?
U 1 1 61A7F17B
P 1750 3450
AR Path="/618968DF/61A7F17B" Ref="#PWR?"  Part="1" 
AR Path="/618968A3/61A7F17B" Ref="#PWR063"  Part="1" 
F 0 "#PWR063" H 1750 3200 50  0001 C CNN
F 1 "GND" H 1750 3300 50  0001 C CNN
F 2 "" H 1750 3450 50  0001 C CNN
F 3 "" H 1750 3450 50  0001 C CNN
	1    1750 3450
	1    0    0    -1  
$EndComp
Wire Wire Line
	1700 3000 1750 3000
Wire Wire Line
	1750 3000 1750 3050
Wire Wire Line
	1750 3000 2300 3000
Connection ~ 1750 3000
$Comp
L Device:R_US R?
U 1 1 61A7F185
P 1750 2800
AR Path="/618968DF/61A7F185" Ref="R?"  Part="1" 
AR Path="/618968A3/61A7F185" Ref="R37"  Part="1" 
F 0 "R37" H 1682 2754 50  0000 R CNN
F 1 "10k" H 1682 2845 50  0000 R CNN
F 2 "Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal" V 1790 2790 50  0001 C CNN
F 3 "~" H 1750 2800 50  0001 C CNN
	1    1750 2800
	-1   0    0    1   
$EndComp
Wire Wire Line
	1750 3350 1750 3450
Wire Wire Line
	1750 3000 1750 2950
Wire Wire Line
	1750 2650 1750 2600
Wire Wire Line
	1100 1900 1150 1900
Wire Wire Line
	1150 1900 1150 2200
Wire Wire Line
	1100 2200 1150 2200
Connection ~ 1150 2200
Wire Wire Line
	1150 2200 1150 2400
Wire Wire Line
	1100 2000 1200 2000
Wire Wire Line
	1200 2000 1200 1700
Wire Wire Line
	1200 1700 1100 1700
Connection ~ 1200 1700
Wire Wire Line
	1100 1800 1400 1800
Wire Wire Line
	1100 2100 1350 2100
Wire Wire Line
	1350 2100 1350 3000
Wire Wire Line
	1350 3000 1400 3000
$Comp
L SchematicLibrary:GND #PWR?
U 1 1 61A9F4A9
P 1150 2400
AR Path="/618968DF/61A9F4A9" Ref="#PWR?"  Part="1" 
AR Path="/618968A3/61A9F4A9" Ref="#PWR058"  Part="1" 
F 0 "#PWR058" H 1150 2150 50  0001 C CNN
F 1 "GND" H 1150 2250 50  0001 C CNN
F 2 "" H 1150 2400 50  0001 C CNN
F 3 "" H 1150 2400 50  0001 C CNN
	1    1150 2400
	1    0    0    -1  
$EndComp
Text Notes 5250 850  0    200  ~ 40
ARDUINO UNO
Text Notes 5200 1550 0    118  Italic 24
Arduino UNO (SLAVE)
Text Notes 900  1050 0    118  Italic 24
Limit Switches
Text Notes 1100 4100 0    118  Italic 24
RX, TX LINK
Text Notes 9600 1900 0    118  Italic 24
Motor1
Text Notes 9600 3700 0    118  Italic 24
Motor2
$Comp
L SchematicLibrary:+5V_U #PWR069
U 1 1 62D51167
P 6600 2050
F 0 "#PWR069" H 6600 1900 50  0001 C CNN
F 1 "+5V_U" H 6615 2223 50  0000 C CNN
F 2 "" H 6600 2050 50  0001 C CNN
F 3 "" H 6600 2050 50  0001 C CNN
	1    6600 2050
	1    0    0    -1  
$EndComp
$Comp
L SchematicLibrary:+3V3_U #PWR068
U 1 1 62D51ABB
P 6200 2050
F 0 "#PWR068" H 6200 1900 50  0001 C CNN
F 1 "+3V3_U" H 6215 2223 50  0000 C CNN
F 2 "" H 6200 2050 50  0001 C CNN
F 3 "" H 6200 2050 50  0001 C CNN
	1    6200 2050
	1    0    0    -1  
$EndComp
Wire Wire Line
	6300 2350 6300 2250
Wire Wire Line
	6600 2050 6600 2250
$Comp
L SchematicLibrary:+5V_U #PWR071
U 1 1 62D6E73A
P 7350 2350
F 0 "#PWR071" H 7350 2200 50  0001 C CNN
F 1 "+5V_U" H 7365 2523 50  0000 C CNN
F 2 "" H 7350 2350 50  0001 C CNN
F 3 "" H 7350 2350 50  0001 C CNN
	1    7350 2350
	1    0    0    -1  
$EndComp
Wire Wire Line
	7350 2350 7350 2400
$Comp
L SchematicLibrary:Arduino_UNO_R3 MOD6
U 1 1 6189A152
P 6100 3350
F 0 "MOD6" H 5800 4300 50  0000 C CNN
F 1 "Arduino_UNO_R3" H 6300 2300 50  0000 L TNN
F 2 "PCB_Library:Arduino_UNO_R3_WithMountingHoles" H 6100 3350 50  0001 C CIN
F 3 "https://www.arduino.cc/en/Main/arduinoBoardUno" H 6100 3350 50  0001 C CNN
F 4 "Arduino UNO R3" H 6550 2300 50  0001 C CNN "=Value"
	1    6100 3350
	1    0    0    -1  
$EndComp
$Comp
L SchematicLibrary:+5V_U #PWR060
U 1 1 62E85BD4
P 1750 1400
F 0 "#PWR060" H 1750 1250 50  0001 C CNN
F 1 "+5V_U" H 1765 1573 50  0000 C CNN
F 2 "" H 1750 1400 50  0001 C CNN
F 3 "" H 1750 1400 50  0001 C CNN
	1    1750 1400
	1    0    0    -1  
$EndComp
Wire Wire Line
	1200 1600 1200 1700
$Comp
L SchematicLibrary:+5V_U #PWR062
U 1 1 62E90826
P 1750 2600
F 0 "#PWR062" H 1750 2450 50  0001 C CNN
F 1 "+5V_U" H 1765 2773 50  0000 C CNN
F 2 "" H 1750 2600 50  0001 C CNN
F 3 "" H 1750 2600 50  0001 C CNN
	1    1750 2600
	1    0    0    -1  
$EndComp
Text Notes 950  5400 0    50   ~ 0
*Make link 1-2 to connect UNO and MEGA.\n*Make link 2-3 to disconnect UNO and MEGA.
NoConn ~ 2100 4400
NoConn ~ 2100 4900
Text Notes 7300 2600 0    59   Italic 12
NF
Wire Wire Line
	6200 2050 6200 2350
$Comp
L SchematicLibrary:+VIN #PWR066
U 1 1 6248FE8C
P 6000 2200
AR Path="/618968A3/6248FE8C" Ref="#PWR066"  Part="1" 
AR Path="/62683160/6248FE8C" Ref="#PWR?"  Part="1" 
F 0 "#PWR066" H 6000 2050 50  0001 C CNN
F 1 "+VIN" H 6015 2373 50  0000 C CNN
F 2 "" H 6000 2200 50  0001 C CNN
F 3 "" H 6000 2200 50  0001 C CNN
	1    6000 2200
	-1   0    0    -1  
$EndComp
Wire Wire Line
	6000 2200 6000 2250
$Comp
L SchematicLibrary:GND #PWR?
U 1 1 625E24CB
P 950 7450
AR Path="/618968DF/625E24CB" Ref="#PWR?"  Part="1" 
AR Path="/618968A3/625E24CB" Ref="#PWR057"  Part="1" 
AR Path="/62683160/625E24CB" Ref="#PWR?"  Part="1" 
F 0 "#PWR057" H 950 7200 50  0001 C CNN
F 1 "GND" H 950 7300 50  0001 C CNN
F 2 "" H 950 7450 50  0001 C CNN
F 3 "" H 950 7450 50  0001 C CNN
	1    950  7450
	1    0    0    -1  
$EndComp
Wire Wire Line
	900  7100 950  7100
Wire Wire Line
	950  7100 950  7400
$Comp
L Device:CP C33
U 1 1 625E24D3
P 1100 7200
AR Path="/618968A3/625E24D3" Ref="C33"  Part="1" 
AR Path="/62683160/625E24D3" Ref="C?"  Part="1" 
F 0 "C33" H 1218 7246 50  0000 L CNN
F 1 "1000uF" H 1218 7155 50  0000 L CNN
F 2 "Capacitor_THT:CP_Radial_D13.0mm_P7.50mm" H 1138 7050 50  0001 C CNN
F 3 "~" H 1100 7200 50  0001 C CNN
	1    1100 7200
	1    0    0    -1  
$EndComp
$Comp
L Device:CP C34
U 1 1 625E24D9
P 1600 7200
AR Path="/618968A3/625E24D9" Ref="C34"  Part="1" 
AR Path="/62683160/625E24D9" Ref="C?"  Part="1" 
F 0 "C34" H 1718 7246 50  0000 L CNN
F 1 "1000uF" H 1718 7155 50  0000 L CNN
F 2 "Capacitor_THT:CP_Radial_D13.0mm_P7.50mm" H 1638 7050 50  0001 C CNN
F 3 "~" H 1600 7200 50  0001 C CNN
	1    1600 7200
	1    0    0    -1  
$EndComp
Wire Wire Line
	950  7400 1100 7400
Wire Wire Line
	1100 7400 1100 7350
Connection ~ 950  7400
Wire Wire Line
	950  7400 950  7450
Connection ~ 1100 7400
Wire Wire Line
	1100 7400 1600 7400
Wire Wire Line
	1600 7400 1600 7350
$Comp
L Device:C C?
U 1 1 625E24E6
P 2100 7200
AR Path="/618968DF/625E24E6" Ref="C?"  Part="1" 
AR Path="/618968A3/625E24E6" Ref="C38"  Part="1" 
AR Path="/62683160/625E24E6" Ref="C?"  Part="1" 
F 0 "C38" H 2215 7246 50  0000 L CNN
F 1 "100nF" H 2215 7155 50  0000 L CNN
F 2 "Capacitor_THT:C_Disc_D5.0mm_W2.5mm_P2.50mm" H 2138 7050 50  0001 C CNN
F 3 "~" H 2100 7200 50  0001 C CNN
	1    2100 7200
	1    0    0    -1  
$EndComp
Connection ~ 1600 7400
Wire Wire Line
	1600 7400 2100 7400
Wire Wire Line
	2100 7400 2100 7350
$Comp
L Device:C C?
U 1 1 625E24EF
P 2600 7200
AR Path="/618968DF/625E24EF" Ref="C?"  Part="1" 
AR Path="/618968A3/625E24EF" Ref="C39"  Part="1" 
AR Path="/62683160/625E24EF" Ref="C?"  Part="1" 
F 0 "C39" H 2715 7246 50  0000 L CNN
F 1 "100nF" H 2715 7155 50  0000 L CNN
F 2 "Capacitor_THT:C_Disc_D5.0mm_W2.5mm_P2.50mm" H 2638 7050 50  0001 C CNN
F 3 "~" H 2600 7200 50  0001 C CNN
	1    2600 7200
	1    0    0    -1  
$EndComp
Connection ~ 2100 7400
Wire Wire Line
	2600 7400 2100 7400
Wire Wire Line
	2600 7350 2600 7400
$Comp
L Device:C C?
U 1 1 625E24FE
P 2050 6700
AR Path="/618968DF/625E24FE" Ref="C?"  Part="1" 
AR Path="/618968A3/625E24FE" Ref="C37"  Part="1" 
AR Path="/62683160/625E24FE" Ref="C?"  Part="1" 
F 0 "C37" V 2000 6750 50  0000 L CNN
F 1 "100nF" V 2000 6400 50  0000 L CNN
F 2 "Capacitor_THT:C_Disc_D5.0mm_W2.5mm_P2.50mm" H 2088 6550 50  0001 C CNN
F 3 "~" H 2050 6700 50  0001 C CNN
	1    2050 6700
	0    -1   1    0   
$EndComp
$Comp
L Diode:1N4007 D4
U 1 1 625E2504
P 1650 6900
AR Path="/618968A3/625E2504" Ref="D4"  Part="1" 
AR Path="/62683160/625E2504" Ref="D?"  Part="1" 
F 0 "D4" H 1450 6850 50  0000 L CNN
F 1 "1N4007" H 1750 6850 50  0000 L CNN
F 2 "Diode_THT:D_DO-41_SOD81_P10.16mm_Horizontal" H 1650 6725 50  0001 C CNN
F 3 "http://www.vishay.com/docs/88503/1n4001.pdf" H 1650 6900 50  0001 C CNN
	1    1650 6900
	1    0    0    1   
$EndComp
Wire Wire Line
	1900 6700 1750 6700
Wire Wire Line
	950  7000 900  7000
Wire Wire Line
	1100 7000 1100 7050
Wire Wire Line
	2600 7000 2600 7050
Wire Wire Line
	2100 7050 2100 7000
Wire Wire Line
	2100 7000 2600 7000
Connection ~ 2100 7000
Wire Wire Line
	1600 7000 2100 7000
Wire Wire Line
	1600 7050 1600 7000
Connection ~ 1600 7000
Wire Wire Line
	1100 7000 1600 7000
Wire Wire Line
	2200 6700 2250 6700
Wire Wire Line
	2250 6900 1800 6900
Wire Wire Line
	1500 6900 1400 6900
Wire Wire Line
	1400 6700 1450 6700
Wire Wire Line
	1750 6500 1750 6550
Wire Wire Line
	1850 6500 1850 6550
Wire Wire Line
	1400 6900 1400 6800
Wire Wire Line
	1400 6800 1400 6700
Connection ~ 1400 6800
Wire Wire Line
	1400 6800 1300 6800
Wire Wire Line
	1300 6550 1750 6550
Wire Wire Line
	950  6550 1300 6550
Connection ~ 1300 6550
Wire Wire Line
	1300 6800 1300 6550
Wire Wire Line
	950  6550 950  7000
Connection ~ 2600 7000
Wire Wire Line
	2600 6550 2600 7000
Connection ~ 2600 6550
Wire Wire Line
	2600 6550 3000 6550
Wire Wire Line
	2250 6700 2250 6800
Wire Wire Line
	2250 6800 2250 6900
Connection ~ 2250 6800
Wire Wire Line
	2250 6800 2350 6800
Wire Wire Line
	2350 6550 2600 6550
Wire Wire Line
	1850 6550 2350 6550
Connection ~ 2350 6550
Wire Wire Line
	2350 6800 2350 6550
$Comp
L Device:R_US R?
U 1 1 625E2530
P 3000 6750
AR Path="/618968DF/625E2530" Ref="R?"  Part="1" 
AR Path="/618968A3/625E2530" Ref="R38"  Part="1" 
AR Path="/62683160/625E2530" Ref="R?"  Part="1" 
F 0 "R38" H 2932 6704 50  0000 R CNN
F 1 "4.7k" H 2932 6795 50  0000 R CNN
F 2 "Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal" V 3040 6740 50  0001 C CNN
F 3 "~" H 3000 6750 50  0001 C CNN
	1    3000 6750
	-1   0    0    1   
$EndComp
Wire Wire Line
	3000 6550 3000 6600
Connection ~ 3000 6550
Wire Wire Line
	3250 6550 3000 6550
$Comp
L Device:LED D5
U 1 1 625E2539
P 3000 7100
AR Path="/618968A3/625E2539" Ref="D5"  Part="1" 
AR Path="/62683160/625E2539" Ref="D?"  Part="1" 
F 0 "D5" V 3039 6982 50  0000 R CNN
F 1 "Green" V 2948 6982 50  0000 R CNN
F 2 "LED_THT:LED_D3.0mm" H 3000 7100 50  0001 C CNN
F 3 "~" H 3000 7100 50  0001 C CNN
	1    3000 7100
	0    -1   -1   0   
$EndComp
Wire Wire Line
	3000 6900 3000 6950
Wire Wire Line
	3000 7250 3000 7400
Connection ~ 2600 7400
Wire Wire Line
	3000 7400 2600 7400
$Comp
L Diode:1N5819 D?
U 1 1 625E2543
P 3400 6550
AR Path="/618968DF/625E2543" Ref="D?"  Part="1" 
AR Path="/618968A3/625E2543" Ref="D6"  Part="1" 
AR Path="/62683160/625E2543" Ref="D?"  Part="1" 
F 0 "D6" H 3400 6650 50  0000 C CNN
F 1 "1N5819" H 3400 6450 50  0000 C CNN
F 2 "Diode_THT:D_DO-41_SOD81_P10.16mm_Horizontal" H 3400 6375 50  0001 C CNN
F 3 "http://www.vishay.com/docs/88525/1n5817.pdf" H 3400 6550 50  0001 C CNN
	1    3400 6550
	-1   0    0    -1  
$EndComp
Wire Wire Line
	3650 6550 3550 6550
$Comp
L Connector:Screw_Terminal_01x02 J10
U 1 1 625E254A
P 1850 6300
AR Path="/618968A3/625E254A" Ref="J10"  Part="1" 
AR Path="/62683160/625E254A" Ref="J?"  Part="1" 
F 0 "J10" V 1950 6250 50  0000 C CNN
F 1 "Screw_Terminal_01x02" V 1950 6250 50  0001 C CNN
F 2 "TerminalBlock_Phoenix:TerminalBlock_Phoenix_MKDS-1,5-2-5.08_1x02_P5.08mm_Horizontal" H 1850 6300 50  0001 C CNN
F 3 "~" H 1850 6300 50  0001 C CNN
	1    1850 6300
	0    1    -1   0   
$EndComp
$Comp
L Connector:Screw_Terminal_01x02 J8
U 1 1 625E2550
P 700 7000
AR Path="/618968A3/625E2550" Ref="J8"  Part="1" 
AR Path="/62683160/625E2550" Ref="J?"  Part="1" 
F 0 "J8" H 700 7100 50  0000 C CNN
F 1 "Screw_Terminal_01x02" H 900 6800 50  0001 C CNN
F 2 "TerminalBlock_Phoenix:TerminalBlock_Phoenix_MKDS-1,5-2-5.08_1x02_P5.08mm_Horizontal" H 700 7000 50  0001 C CNN
F 3 "~" H 700 7000 50  0001 C CNN
	1    700  7000
	-1   0    0    -1  
$EndComp
Text Notes 900  6000 0    118  Italic 24
12V - PSU
Wire Wire Line
	3650 6450 3650 6550
$Comp
L SchematicLibrary:+VIN #PWR064
U 1 1 625E2558
P 3650 6450
AR Path="/618968A3/625E2558" Ref="#PWR064"  Part="1" 
AR Path="/62683160/625E2558" Ref="#PWR?"  Part="1" 
F 0 "#PWR064" H 3650 6300 50  0001 C CNN
F 1 "+VIN" H 3665 6623 50  0000 C CNN
F 2 "" H 3650 6450 50  0001 C CNN
F 3 "" H 3650 6450 50  0001 C CNN
	1    3650 6450
	1    0    0    -1  
$EndComp
$Comp
L SchematicLibrary:+VIN #PWR059
U 1 1 6261746A
P 1200 1600
AR Path="/618968A3/6261746A" Ref="#PWR059"  Part="1" 
AR Path="/62683160/6261746A" Ref="#PWR?"  Part="1" 
F 0 "#PWR059" H 1200 1450 50  0001 C CNN
F 1 "+VIN" H 1215 1773 50  0000 C CNN
F 2 "" H 1200 1600 50  0001 C CNN
F 3 "" H 1200 1600 50  0001 C CNN
	1    1200 1600
	1    0    0    -1  
$EndComp
$Comp
L power:PWR_FLAG #FLG07
U 1 1 6261FCDA
P 6200 4500
F 0 "#FLG07" H 6200 4575 50  0001 C CNN
F 1 "PWR_FLAG" V 6200 4628 50  0000 L CNN
F 2 "" H 6200 4500 50  0001 C CNN
F 3 "~" H 6200 4500 50  0001 C CNN
	1    6200 4500
	0    1    1    0   
$EndComp
Wire Wire Line
	6600 2250 6300 2250
Connection ~ 6200 4500
$Comp
L power:PWR_FLAG #FLG08
U 1 1 6262BB42
P 6600 2250
F 0 "#FLG08" H 6600 2325 50  0001 C CNN
F 1 "PWR_FLAG" V 6600 2378 50  0000 L CNN
F 2 "" H 6600 2250 50  0001 C CNN
F 3 "~" H 6600 2250 50  0001 C CNN
	1    6600 2250
	0    1    1    0   
$EndComp
Connection ~ 6600 2250
$Comp
L power:PWR_FLAG #FLG06
U 1 1 626330C2
P 6000 2250
F 0 "#FLG06" H 6000 2325 50  0001 C CNN
F 1 "PWR_FLAG" V 6000 2377 50  0000 L CNN
F 2 "" H 6000 2250 50  0001 C CNN
F 3 "~" H 6000 2250 50  0001 C CNN
	1    6000 2250
	0    -1   -1   0   
$EndComp
Connection ~ 6000 2250
Wire Wire Line
	6000 2250 6000 2350
$Comp
L SchematicLibrary:+3V3_U #PWR065
U 1 1 62633DAE
P 5050 2000
F 0 "#PWR065" H 5050 1850 50  0001 C CNN
F 1 "+3V3_U" H 5065 2173 50  0000 C CNN
F 2 "" H 5050 2000 50  0001 C CNN
F 3 "" H 5050 2000 50  0001 C CNN
	1    5050 2000
	1    0    0    -1  
$EndComp
$Comp
L power:PWR_FLAG #FLG05
U 1 1 62634090
P 5050 2050
F 0 "#FLG05" H 5050 2125 50  0001 C CNN
F 1 "PWR_FLAG" H 5050 2223 50  0000 C CNN
F 2 "" H 5050 2050 50  0001 C CNN
F 3 "~" H 5050 2050 50  0001 C CNN
	1    5050 2050
	-1   0    0    1   
$EndComp
Wire Wire Line
	5050 2000 5050 2050
NoConn ~ 5600 3850
NoConn ~ 5600 3950
NoConn ~ 5600 4050
Text Notes 1600 6950 0    59   Italic 12
NF
$Comp
L Device:R_US R?
U 1 1 625E24F8
P 1600 6700
AR Path="/618968DF/625E24F8" Ref="R?"  Part="1" 
AR Path="/618968A3/625E24F8" Ref="R35"  Part="1" 
AR Path="/62683160/625E24F8" Ref="R?"  Part="1" 
F 0 "R35" V 1650 6600 50  0000 R CNN
F 1 "1k" V 1650 6900 50  0000 R CNN
F 2 "Resistor_THT:R_Axial_DIN0207_L6.3mm_D2.5mm_P10.16mm_Horizontal" V 1640 6690 50  0001 C CNN
F 3 "~" H 1600 6700 50  0001 C CNN
	1    1600 6700
	0    1    -1   0   
$EndComp
$EndSCHEMATC
